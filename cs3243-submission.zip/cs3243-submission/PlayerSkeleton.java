import java.util.Arrays;

public class PlayerSkeleton {

	//implement this function to have a working system
	public int pickMove(State s, int[][] legalMoves) {
		// TODO: put in chosen weights
		return pickMove(s, legalMoves, new double[]{10.0, -10.0, -7.631455394594079, 2.1425255943282537, 0.19485158741367403, 
			-4.781899234177633}, new Heuristic(false, true));
	}

	public int pickMove(State s, int[][] legalMoves, double[] weights) {
		//Test all possible moves of the piece on the board and choose the move with the best heuristic score 
		int best = tryPossibleMoves(s, legalMoves, weights, null);

		return best;
	}

	public int pickMove(State s, int[][] legalMoves, double[] weights, Heuristic h) {
		//Test all possible moves of the piece on the board and choose the move with the best heuristic score 
		int best = tryPossibleMoves(s, legalMoves, weights, h);

		return best;
	}

	/**
	* This method test all possible moves of the piece and returns the move with the best heuristic score
	* @param s (current state), legalMoves (possible moves for current piece)
	* @return move with best (highest) heuristic score
	**/
	private int tryPossibleMoves(State s, int[][] legalMoves, double[] weights, Heuristic h) {

		// By default use new set of features
		if (h == null) {
			h = new Heuristic(false, true);
		}

		//legalMoves = all possible moves of the current piece.
		//Step 1. Apply each move (action) to get the change field (board configuration).
		//Step 2. Apply Heuristic.evaluate(s) to get the heuristic score from the move.
		//Step 3. Get the best move.
		double bestScore = Double.NEGATIVE_INFINITY;
		int bestMove = 0;

		for(int i=0; i<legalMoves.length; i++) {
			TempState ts = new TempState(s);
			int prevCleared = s.getRowsCleared();
			//Step 1
			int orient = legalMoves[i][0];
			int slot = legalMoves[i][1];
			boolean possible = ts.makeMove(orient, slot);
			if(!possible) {
				continue;
			} 
			//Step 2
            ts.setPrevCleared(prevCleared);
			ts.setOrientAndSlot(orient, slot);
			Evaluator e = new Evaluator(h, ts, weights);
			double score = e.evaluate(); 

			//Step 3
			if(score > bestScore) {
				bestScore = score;
				bestMove = i;
			}
		}
		return bestMove;
	}
	
	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		State s = new State();
		new TFrame(s);
		PlayerSkeleton p = new PlayerSkeleton();
		while(!s.hasLost()) {
			s.makeMove(p.pickMove(s, s.legalMoves()));
			s.draw();
			s.drawNext(0,0);
			try {
				Thread.sleep(0);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		long end = System.currentTimeMillis();
		System.out.println("You have completed "+s.getRowsCleared()+" rows.");
	}

	class Heuristic {
		private int TOTAL_NUM_FEATURES = 9;

		// Indices for each feature to keep track of which feature to use
		private int INDEX_ROWS_CLEARED = 0;
		private int INDEX_COL_HEIGHT = 1;
		private int INDEX_COL_HEIGHT_DIFF = 2;
		private int INDEX_MAX_COL_HEIGHT = 3;
		private int INDEX_NUM_HOLES = 4;
		private int INDEX_LANDING_HEIGHT = 5;
		private int INDEX_ROW_TRANSITIONS = 6;
		private int INDEX_COL_TRANSITIONS = 7;
		private int INDEX_WELL_SUMS = 8;
		private int[] INDEX_OLD_FEATURES = new int[]{INDEX_ROWS_CLEARED, INDEX_COL_HEIGHT, INDEX_COL_HEIGHT_DIFF,
			INDEX_MAX_COL_HEIGHT, INDEX_NUM_HOLES};
		private int[] INDEX_NEW_FEATURES = new int[]{INDEX_ROWS_CLEARED, INDEX_NUM_HOLES, INDEX_LANDING_HEIGHT, 
			INDEX_ROW_TRANSITIONS, INDEX_COL_TRANSITIONS, INDEX_WELL_SUMS};

		// Flags for features
		private char[] featureFlags;
		private int numFeatures;


	    public Heuristic(boolean useOldFeatures, boolean useNewFeatures) {
	        this.featureFlags = new char[TOTAL_NUM_FEATURES];
	        setNumFeatures(useOldFeatures, useNewFeatures);
	    }

	 	public Heuristic(boolean useOldFeatures, boolean useNewFeatures, String featureBits) {
	        this.featureFlags = featureBits.toCharArray();
	        setNumFeatures(useOldFeatures, useNewFeatures);
	    }
	    

		private void setFixedFeatures(int[] indices, boolean isUse) {
			if (isUse) {
				for (int i = 0; i < indices.length; i++) {
					featureFlags[indices[i]] = '1';
				}
			}
		}

		public void setNumFeatures(boolean useOldFeatures, boolean useNewFeatures) {
			// Transfer useNewFeatures/useOldFeatures to feature bits
			setFixedFeatures(INDEX_NEW_FEATURES, useNewFeatures);
			setFixedFeatures(INDEX_OLD_FEATURES, useOldFeatures);

			numFeatures = 0;
			for (int i = 0; i < featureFlags.length; i++) {
				if (featureFlags[i] == '1') {
					if (i == INDEX_COL_HEIGHT) {
						numFeatures += 10;
					} else if (i == INDEX_COL_HEIGHT_DIFF) {
						numFeatures += 9;
					} else {
						numFeatures++;
					}
				}
			}
		}

		public int getNumFeatures() {
			return numFeatures;
		}

		public char[] getFeatureFlags() {
			return featureFlags;
		}

		public String printFeatureInfo() {
			return "Feature set used: " + Arrays.toString(featureFlags);
		}

		public int getIndexRowsCleared() {
			return INDEX_ROWS_CLEARED;
		}

		public int getIndexColHeight() {
			return INDEX_COL_HEIGHT;
		}

		public int getIndexColHeightDiff() {
			return INDEX_COL_HEIGHT_DIFF;
		}

		public int getIndexMaxColHeight() {
			return INDEX_MAX_COL_HEIGHT;
		}

		public int getIndexNumHoles() {
			return INDEX_NUM_HOLES;
		}
		public int getIndexLandingHeight() {
			return INDEX_LANDING_HEIGHT;
		}

		public int getIndexRowTransitions() {
			return INDEX_ROW_TRANSITIONS;
		}
		public int getIndexColTransitions() {
			return INDEX_COL_TRANSITIONS;
		}

		public int getIndexWellSums() {
			return INDEX_WELL_SUMS;
		}
	}

	class TempState extends State {
		private int COLS = 10;
		private int ROWS = 21;

		private int[] top;
		private int[][] field;
		private int[][] pWidth;
		private int[][] pHeight;
		private int[][][] pBottom;
		private int[][][] pTop;
		private int prevCleared;
		private int cleared;
		private int nextPiece;
		private int stateOrient;
		private int stateSlot;

	    public TempState(State s) {
			this.pBottom = s.getpBottom();
			this.pTop = s.getpTop();
			this.pHeight = s.getpHeight();
			this.pWidth = s.getpWidth();
			this.cleared = s.getRowsCleared();
			this.nextPiece = s.getNextPiece();
			this.top = copyArray(s.getTop());
			this.field = copyArray(s.getField());
		}

		public int[][] getField() {
			return this.field;
		}

		public int getRowsCleared() {
			return cleared;
		}

		public int getRowsPrevCleared() {
	        return prevCleared;
	    }

		public int getStateSlot () {
		    return stateSlot;
	    }

	    public int getHeightOfPeice() {
		    return pHeight[nextPiece][stateOrient];
	    }

	    public int getHeightOfCol(int slot) {
		    return top[slot];
	    }

		//returns false if you lose - true otherwise
		public boolean makeMove(int orient, int slot) {
	        //height if the first column makes contact
			int height = top[slot]-pBottom[nextPiece][orient][0];
			//for each column beyond the first in the piece
			for(int c = 1; c < pWidth[nextPiece][orient];c++) {
				height = Math.max(height,top[slot+c]-pBottom[nextPiece][orient][c]);
			}
			
			//check if game ended
			if(height+pHeight[nextPiece][orient] >= ROWS) {
				//lost = true;
				return false;
			}

			
			//for each column in the piece - fill in the appropriate blocks
			for(int i = 0; i < pWidth[nextPiece][orient]; i++) {
				
				//from bottom to top of brick
				for(int h = height+pBottom[nextPiece][orient][i]; h < height+pTop[nextPiece][orient][i]; h++) {
					field[h][i+slot] = 1;
				}
			}
			
			//adjust top
			for(int c = 0; c < pWidth[nextPiece][orient]; c++) {
				top[slot+c]=height+pTop[nextPiece][orient][c];
			}
			
			int rowsCleared = 0;
			
			//check for full rows - starting at the top
			for(int r = height+pHeight[nextPiece][orient]-1; r >= height; r--) {
				//check all columns in the row
				boolean full = true;
				for(int c = 0; c < COLS; c++) {
					if(field[r][c] == 0) {
						full = false;
						break;
					}
				}
				//if the row was full - remove it and slide above stuff down
				if(full) {
					rowsCleared++;				//for each column
					cleared++;
					for(int c = 0; c < COLS; c++) {

						//slide down all bricks
						for(int i = r; i < top[c]; i++) {
							field[i][c] = field[i+1][c];
						}
						//lower the top
						top[c]--;
						while(top[c]>=1 && field[top[c]-1][c]==0) {
							top[c]--;
						}
					}
				}
			}

			return true;
		}

		public void setOrientAndSlot (int orient, int slot){
		    this.stateOrient = orient;
		    this.stateSlot = slot;
	    }

		/**
		* This method makes a copy of an int array.
		* @param originalArray (array to copy)
		* @return newArray (deep copy of the array)
		**/
		private int[] copyArray(int[] originalArray) {
			if(originalArray == null) {
				return null;
			}

			int[] newArray = Arrays.copyOf(originalArray, originalArray.length);
			return newArray;
		}

		/**
		* This method makes a copy of an 2D int array.
		* @param originalArray (array to copy)
		* @return newArray (deep copy of the array)
		**/
		private int[][] copyArray(int[][] originalArray) {
			if(originalArray == null) {
				return null;
			}

			int[][] newArray = new int[originalArray.length][];
			for(int i=0; i<originalArray.length; i++) {
				newArray[i] = Arrays.copyOf(originalArray[i], originalArray[i].length);
			}
			return newArray;
		}

		/**
		* This method prints current board configuration
		* @param currentField
		**/
		public void printField(int[][] currentField) {
			System.out.println("========Field==============");
			for(int i=0; i<currentField.length; i++) {
				for(int j=0; j<currentField[i].length; j++) {
					System.out.print(currentField[i][j] + "\t");
				}
				System.out.println();
			}
		}

	    public void setPrevCleared (int prevCleared) {
	        this.prevCleared = prevCleared;
	    }
	}

	class Evaluator {
		private int TOTAL_NUM_FEATURES = 9;

		// Indices for each feature to keep track of which feature to use
		private int INDEX_ROWS_CLEARED;
		private int INDEX_COL_HEIGHT;
		private int INDEX_COL_HEIGHT_DIFF;
		private int INDEX_MAX_COL_HEIGHT;
		private int INDEX_NUM_HOLES;
		private int INDEX_LANDING_HEIGHT;
		private int INDEX_ROW_TRANSITIONS;
		private int INDEX_COL_TRANSITIONS;
		private int INDEX_WELL_SUMS;
				
		// Flags for features
		private char[] featureFlags;
		private int numFeatures;
		private double[] weights;
		private int weightCounter;
		private TempState s;
		private int[] colHeights;

		public Evaluator(Heuristic h, TempState s, double[] inputWeights) {
			this.featureFlags = h.getFeatureFlags();
			this.numFeatures = h.getNumFeatures();
			this.weightCounter = 0;
			this.weights = inputWeights;
			this.s = s;
			INDEX_ROWS_CLEARED = h.getIndexRowsCleared();
			INDEX_COL_HEIGHT = h.getIndexColHeight();
			INDEX_COL_HEIGHT_DIFF = h.getIndexColHeightDiff();
			INDEX_MAX_COL_HEIGHT = h.getIndexMaxColHeight();
			INDEX_NUM_HOLES = h.getIndexNumHoles();
			INDEX_LANDING_HEIGHT = h.getIndexLandingHeight();
			INDEX_ROW_TRANSITIONS = h.getIndexRowTransitions();
			INDEX_COL_TRANSITIONS = h.getIndexColTransitions();
			INDEX_WELL_SUMS = h.getIndexWellSums();
		}

		public double evaluate() {
			int[][] field = s.getField();
			this.colHeights = colHeights(field);

			return weightedNumRowsCleared() 
					+ weightedSumColHeight(colHeights) 
					+ weightedSumColDiff(colHeights) 
					+ weightedMaxColHeight(colHeights) 
					+ weightedNumHoles(field, colHeights) 
					+ weightedLandingHeight(s) 
					+ weightedNumRowTranstions(field) 
					+ weightedNumColTranstions(field)
	                + weightedWellSums(field);
		}


		/** METHODS TO COMPUTE FEATURE SUM **/
		// Returns weighted number of rows cleared by playing this move
		private double weightedNumRowsCleared() {
			if (featureFlags[INDEX_ROWS_CLEARED] != '1') {
				return 0;
			}
		    int rowsEliminated = s.getRowsCleared() - s.getRowsPrevCleared();
		    return getNextWeight() * rowsEliminated;
		}

		// Returns weighted sum of column heights
		private double weightedSumColHeight(int[] colHeights) {
			if (featureFlags[INDEX_COL_HEIGHT] != '1') {
				return 0;
			}

			double weightedSum = 0;

			// iterate through columns, count height for each col
			for (int i = 0; i < colHeights.length; i++) {
				weightedSum += getNextWeight() * colHeights[i];
			}

			return weightedSum;
		}

		// Returns weighted sum of absolute differences between adjacent columns
		private double weightedSumColDiff(int[] colHeights) {
			if (featureFlags[INDEX_COL_HEIGHT_DIFF] != '1') {
				return 0;
			}

			double weightedSum = 0;

			for (int i = 1; i < colHeights.length; i++) {
				weightedSum += getNextWeight() * Math.abs(colHeights[i] - colHeights[i-1]);
			}
			return weightedSum;
		}

		// Returns weighted max col
		private double weightedMaxColHeight(int[] colHeights) {
			if (featureFlags[INDEX_MAX_COL_HEIGHT] != '1') {
				return 0;
			}

			int max = 0;

			for (int i = 0; i < colHeights.length; i++) {
				if (colHeights[i] > max) {
					max = colHeights[i];
				}
			}

			return getNextWeight() * max;
		}

		// Returns weighted number of holes
		private double weightedNumHoles(int[][] field, int[] colHeights) {
			if (featureFlags[INDEX_NUM_HOLES] != '1') {
				return 0;
			}

			int numHoles = 0;

			for (int col = 0; col < colHeights.length; col++) {
				for (int row = colHeights[col] - 1; row >= 0; row--) {
					if (field[row][col] == 0) {
						numHoles++;
					}
				}
			}

			return getNextWeight() * numHoles;
		}

	    private double weightedLandingHeight (TempState s) {
			if (featureFlags[INDEX_LANDING_HEIGHT] != '1') {
				return 0;
			}

		    return getNextWeight() * landingHeight(s);
	    }

	    // Landing Height:
	    // The height where the piece is put = the height of the column BEFORE piece is put + (the height of the piece / 2)
	    // Also equivalent to height of column AFTER piece is put - (the height of the piece / 2) (?)
	    private int landingHeight(TempState s) {

		    int heightPiece = s.getHeightOfPeice();
		    int landingHeight = s.getHeightOfCol(s.getStateSlot()) - heightPiece/2;

	        return landingHeight;
	    }

	    private double weightedNumRowTranstions(int[][] field) {
			if (featureFlags[INDEX_ROW_TRANSITIONS] != '1') {
				return 0;
			}

	        return getNextWeight() * numRowTransitions(field);
	    }

	    // The total number of row transitions.
	    // A row transition occurs when an empty cell is adjacent to a filled cell
	    // on the same row and vice versa.
		private int numRowTransitions(int[][] field) {
		    int count = 0;
		    int numRows = field.length;
		    int numCols = field[0].length;
	        for (int i = 0; i < numRows; i++) {
	            for (int j = 0; j < numCols - 1; j++) {
	                if (field[i][j] == 0 && field[i][j+1] != 0
	                        || field[i][j] != 0 && field[i][j+1] == 0){
	                    count++;
	                }
	            }
	        }
	        return count;
	    }

	    private double weightedNumColTranstions(int[][] field) {
			if (featureFlags[INDEX_COL_TRANSITIONS] != '1') {
				return 0;
			}

	        return getNextWeight() * numColTransitions(field);
	    }

	    // The total number of column transitions.
	    // A column transition occurs when an empty cell is adjacent to a filled cell
	    // on the same column and vice versa.
	    private int numColTransitions(int[][] field) {
	        int count = 0;
	        int numRows = field.length;
	        int numCols = field[0].length;
	        for (int j = 0; j < numCols; j++) {
	            for (int i = 0; i < numRows - 1; i++) {
	                if (field[i][j] == 0 && field[i+1][j] != 0
	                        || field[i][j] != 0 && field[i+1][j] == 0){
	                    count++;
	                }
	            }
	        }
	        return count;
	    }

	    private double weightedWellSums(int[][] field) {
			if (featureFlags[INDEX_WELL_SUMS] != '1') {
				return 0;
			}

	        return getNextWeight() * wellSums(field);
	    }

	    // A well is a succession of empty cells such that their left cells and right cells are both filled.
	    // Example:
	    // |1101100010|
	    // |1101101010|
	    // |1101101000| | denotes left/right edge border
	    // returns 8
	    private int wellSums(int[][] field) {
	        int count = 0;
	        int numRows = field.length;
	        int numCols = field[0].length;
	        for (int i = 0; i < numRows; i++) {
	            for (int j = 0; j < numCols; j++) {
	                if (field[i][j] == 0){ // if cell is empty
	                        if (j > 0 && j < numCols - 1 && field[i][j - 1] != 0 && field[i][j + 1] != 0) {
	                            count += exploreWell(i, j, field);
	                        } else if (j == 0 && field[i][j+1] !=0) {
	                            count += exploreWellLeftSide(i, field);
	                        } else if (j == numCols - 1 && field[i][j-1] != 0){
	                            count += exploreWellRightSide(i, field);
	                        }
	                }

	            }
	        }

	        return count;
	    }

	    // explore up the rows within the column
	    private int exploreWell(int startRow, int startColumn, int[][] field) {
		    // if this empty column is part of an existing well. Don't bother
		    if (startRow != 0
	                && field[startRow-1][startColumn] == 0
	                && field[startRow-1][startColumn - 1] != 0
	                && field[startRow-1][startColumn + 1] != 0) {
	            return 0;
	        }

		    int count = 0;
		    while(field[startRow][startColumn] == 0
	                && field[startRow][startColumn-1] != 0
	                && field[startRow][startColumn+1] != 0) {
		        count++;
		        startRow++;
	        }
	        if (field[startRow][startColumn] != 0) {
	            return 0;
	        }
		    return sumFromOneToN(count);
	    }

	    // explore up the rows within the column for wells by the left wall
	    private int exploreWellLeftSide(int startRow, int[][] field) {
	        // if this empty column is part of an existing well. Don't bother
	        if (startRow != 0
	                && field[startRow-1][0] == 0
	                && field[startRow-1][1] != 0) {
	            return 0;
	        }

	        int count = 0;
	        while(field[startRow][0] == 0
	                && field[startRow][1] != 0) {
	            count++;
	            startRow++;
	        }
	        if (field[startRow][0] != 0) {
	            return 0;
	        }
	        return sumFromOneToN(count);
	    }

	    // explore up the rows within the column for wells by the right wall
	    private int exploreWellRightSide(int startRow, int[][] field) {
	        int numCols = field[0].length;
		    // if this empty column is part of an existing well. Don't bother
	        if (startRow != 0
	                && field[startRow-1][numCols - 1] == 0
	                && field[startRow-1][numCols - 2] != 0) {
	            return 0;
	        }

	        int count = 0;
	        while(field[startRow][numCols - 1] == 0
	                && field[startRow][numCols - 2] != 0) {
	            count++;
	            startRow++;
	        }
	        if (field[startRow][numCols -1] != 0) {
	            return 0;
	        }
	        return sumFromOneToN(count);
	    }

		/** HELPER METHODS **/
		// Returns array of column heights
		private int[] colHeights(int[][] field) {
			int[] colHeights = new int[field[0].length];

			for (int col = 0; col < field[0].length; col++) {
				int row = field.length - 1;

				while (row >= 0 && field[row][col] == 0) {
					row--;
				}
				colHeights[col] = row + 1;
			}

			return colHeights;
		}

	    // Given an N returns sum From One to N.
	    // eg: Input N. Ouput 1 + 2 + 3 + 4 + 5.
	    // Uses Sum of AP.
	    private int sumFromOneToN(int N) {
		    return (N*(N+1))/2;
	    }

		private double getNextWeight() {
			return weights[weightCounter++];
		}
	}

}
